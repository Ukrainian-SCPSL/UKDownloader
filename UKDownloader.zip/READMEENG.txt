TUTORIAL


To set the localization, you need to follow these steps:
1. Open Steam -> Library -> Manage -> View local files
2. Open the Translations folder.
3. Copy the path to the folder from above.
4. In the program, click on “...”.
5. Paste the path to the Translations folder in the line above and click on “Select folder”.
6. Click on “Download”.
7. Wait for the download.

You're done! You can set the Ukrainian language in the game settings.

You can keep the program to update the localization in the future.

Also, the installation cache is stored in the Documents/UKDownloader_cash folder, so you can clear this folder after installing the localization.